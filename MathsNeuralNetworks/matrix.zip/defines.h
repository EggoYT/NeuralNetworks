#pragma once
template<size_t size>
class Vector;
template<size_t cols, size_t rows>
class Matrix;