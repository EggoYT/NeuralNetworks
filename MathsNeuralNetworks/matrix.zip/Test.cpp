#include <iostream>
#include <string>
#include "vec.cpp"
#include "mat.cpp"

int main() {
	Matrix<5, 5> m(5.0);
	//auto a = m & Matrix<3, 3>(0.5);
	auto b = m & Matrix<6, 6>(0.5);
	return 0;
}