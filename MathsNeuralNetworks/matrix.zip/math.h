#pragma once
#include <chrono>
using frac = float;

struct Timer {
	std::chrono::time_point<std::chrono::high_resolution_clock> point;

	Timer() {
		reset();
	}

	void reset() {
		point = std::chrono::high_resolution_clock::now();
	}

	double get_millis() {
		return std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - point).count();
	}
};

template<size_t... index, typename F, typename... Tp>
constexpr void apply_sequence(std::integer_sequence<size_t, index...>, F&& f, Tp&&... args) {
	(void(micro_std::forward<F>(f)(index, micro_std::forward<Tp>(args)...)), ...);
}
